package scrabble.util;

import java.util.Arrays;

import scrabble.data.HashTableWords;

public class Permutation {
	String word;
	String normalized;
	
	
	public Permutation(String word) { //also get the normalized version, so it doesn't execute the method every time it is called
		
		this.word = word.toLowerCase();
		char[] arr = word.toCharArray();
		Arrays.sort(arr);
		normalized = new String(arr);
	}

	@Override
	
	//you can improve the math here
	public int hashCode() {
		int code = 0;
		char[] arr = word.toCharArray();
		for (int i = 0; i < arr.length; i++) {
			code += arr[i]*31 +7;
		}
		return code;
	}

	@Override
	public boolean equals(Object obj) {
		this.getNormalized();
		if(obj.getClass() != this.getClass()){ //if it is not a permutation, return false
			return false;
		}
		Permutation p = (Permutation) obj;
		return this.normalized.contentEquals(p.getNormalized()) && this.hashCode() == p.hashCode();
	}

	@Override
	public String toString() {
		return "["+ getNormalized() + "] " + getWord() ;
	}

	public String getNormalized() {
		return normalized;
	}

	public String getWord() {
		return word;
	}

	public int length() {
		return word.length();
	}

}
