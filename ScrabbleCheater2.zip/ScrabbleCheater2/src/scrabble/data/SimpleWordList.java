package scrabble.data;

import java.io.File;
import java.io.FileNotFoundException;
import java.security.acl.Permission;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import scrabble.util.Permutation;

public class SimpleWordList implements WordList {
	static ArrayList<String> words = new ArrayList<>();
	HashTableWords hashTable = new HashTableWords();
	
	//ArrayList<Permutation> words = new ArrayList<>(); 
	
	@Override
	public Set<String> validWordsUsingAllTiles(String tileRackPart) {
		tileRackPart.toLowerCase();
		Set<String> permutationSet = new HashSet<>();

		
		/*
		 * Version with Set<String>
		 *
		permutations(tileRackPart, 0, tileRackPart.length() -1, permutationSet);
		//check if it is in the list missing
		this.initFromFile("C:/Users/Anele/eclipse-workspace/lab11/ScrabbleCheater/wordlists/sowpods.txt");
		boolean valid = false;
		for(String s : permutationSet) { // all the permutations of the tiles
			for (int i = 0; i < words.size(); i++) {
				if(words.get(i).equals(s)) 
					valid = true;
			}
			if(!valid)
				permutationSet.remove(s);
		}
		*/
		
		
		
		/*
		 * improved version using Permutation class 
		 */
		
		ArrayList<Permutation> permutationList = new ArrayList<>();
		permutations2(tileRackPart, 0, tileRackPart.length() -1, permutationList);
		
		//check if it is in the list missing
		for(Permutation p : permutationList) {
			if (!hashTable.contains(p))
				permutationList.remove(p);
			else {
				permutationSet.add(p.getWord());
			}
		}
		
		return permutationSet;
	}

	@Override
	public Set<String> allValidWords(String tileRack) {
		
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(String word) {
		words.add(word);
		return false;
	}

	@Override
	public boolean addAll(Collection<String> words) {
		if(words.isEmpty()) 
			return false;
		Iterator<String> iterate = words.iterator();
		while(iterate.hasNext()) {
			this.words.add(iterate.next());
		}
		
		return true;
	}

	@Override
	public int size() {
		return words.size();
	}
	

	@Override
	
	//read from a file and put the words into an array list
	public WordList initFromFile(String fileName) {
		File file = new File(fileName); 
		Scanner sc;
		String line; 
		try {
			sc = new Scanner(file);
			while (sc.hasNext()) {
				line = sc.nextLine();
				String[] currentLine = line.split("[, ]");
				for (int i = 0; i < currentLine.length; i ++) {
					words.add(currentLine[i]);
				}	
			}
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		
		return this;
	
	}
	
	private void swap(char[] arr, int m, int n) {
		char temp = arr[m];
		arr[m] = arr[n];
		arr[n] = temp;
	}
	
	private void permutations(String word, int left, int right, Set<String> res) {
		if (left == right)
			res.add(word);
		else {
			for (int i = left; i <= right ; i++) {
				swap(word.toCharArray(), left, i);
				permutations(word, left + 1, right, res);
				swap(word.toCharArray(), left, i);
			}
		}
	}
	//the same, but for the version with ArrayList<Permutation>
	private void permutations2(String word, int left, int right, ArrayList<Permutation> res) {
		if (left == right)
				res.add(new Permutation(word));
		else {
			for (int i = left; i <= right ; i++) {
				swap(word.toCharArray(), left, i);
				permutations2(word, left + 1, right, res);
				swap(word.toCharArray(), left, i);
			}
		}
			
	}

}
