package scrabble.data;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import scrabble.util.Permutation;

public class HashWordList implements WordList  {
	Map<String, ArrayList<String>> wordMap2 = new HashMap<>();
	//HashTableWords hashTable = new HashTableWords();
	
	public static void main(String[] args) {
		//so we can read from the command line
		HashWordList main = new HashWordList();
		main.initFromFile("C:/Users/Anele/eclipse-workspace/lab11/ScrabbleCheater/wordlists/sowpods.txt");
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("You are playing scrabble and need some help? Tell us what you want!");
		System.out.println("Enter 1 to check if a given word is valid");
		System.out.println("Enter 2 to get all valid permutations of your tails");
		System.out.println("Enter 3 to exit");
		System.out.println("Attention- any other input will not be accepted :)");
		int choice = scanner.nextInt();
		boolean finished = false;
		while(!finished) {
			if(choice == 1) {
				System.out.println("Enter the word that you want to check: ");
				String word = scanner.next();
				
				String check = new Permutation(word).getNormalized();
				if(main.wordMap2.containsKey(check)) {
					if(main.wordMap2.get(check).contains(word))
						System.out.println("Valid");
				}
				else {
					System.out.println("Nope");
				}
				finished = true;
			}
			if(choice == 2) {
				System.out.println("Enter the tails as a word, without a space between them: ");
				String word = scanner.next();
				String tails = new Permutation(word).getNormalized();
				for(String s : main.wordMap2.get(tails)) {
					System.out.println(s);
				}
				System.out.println("Here you go.");
				
			}
			if(choice == 3) {
				System.out.println("Byeee");
				finished = true;
			}
			else {
				System.out.println("Told you no other input will be accepted...");
				System.out.println("Try again..");
			}
		}
		scanner.close();
		System.exit(0);
		
		
	}
	
	public Set<String> validWordsUsingAllTiles(String tileRackPart) {
		Set<String> permutationSet = new HashSet<>();
		ArrayList<Permutation> permutationList = new ArrayList<>();
		permutations2(tileRackPart, 0, tileRackPart.length() -1, permutationList);
		
		//check if it is in the list
		ArrayList<String> values = wordMap2.get(new Permutation(tileRackPart).getNormalized());
		
		boolean valid = false;
		for (int i = 0; i < permutationList.size(); i++) {
			for (int j = 0; j < values.size(); j++) {
				Permutation p1 = new Permutation(values.get(j));
				if(p1.equals(permutationList.get(i))) {
					valid = true;
				}
				if(!valid)
					permutationList.remove(i);
				else {
					permutationSet.add(p1.getWord());
				}
				valid = false;
			}
		}
	
		return permutationSet;
	
	}

	/**
	 * returns all words that can be build with the tileRack, that is,
	 * permutations of all subsets of the tileRack.
	 * 
	 * @param tileRack
	 * @return
	 */
	public Set<String> allValidWords(String tileRack){
		return null;
	}

	//add a single word
	public boolean add(String word) {
		String norm = new Permutation(word).getNormalized();
		if(word == null) 
			return false;
		else if(wordMap2.containsKey(norm) && !getValuesList(norm).contains(word)) {
			getValuesList(norm).add(word);
			return true;
		}
		else {
			ArrayList<String> permNew = new ArrayList<>();
			wordMap2.put(norm, permNew);
			getValuesList(norm).add(word);
			return true;
		}
			 
		
	}

	public boolean addAll(Collection<String> words) {
		if(words.isEmpty()) return false;
		for(String s : words) {
			String s1 = new Permutation(s).getNormalized();
		
			if (wordMap2.containsKey(s1))
				getValuesList(s1).add(s);
			else {
				ArrayList<String> permNew = new ArrayList<>();
				wordMap2.put(s1, permNew);
				getValuesList(s1).add(s);
			}
		}
		return true;
	}

	//numbers of stored words
	public int size() {
		
		return wordMap2.size();
	}

	//puts the words into the hash map, words(normalized) are keys , values are set to null if there is no auch valid 
	//permutation, else the word is added as a valid permutation  
	public WordList initFromFile(String fileName) {
		File file = new File(fileName); 
		Scanner sc;
		String line; 
		try {
			sc = new Scanner(file);
			while (sc.hasNext()) {
				line = sc.nextLine();
				String[] currentLine = line.split("[, ]");
				for (int i = 0; i < currentLine.length; i ++) {
					String s = new Permutation(currentLine[i]).getNormalized();
					if (wordMap2.containsKey(s))
						getValuesList(s).add(currentLine[i]);
					else {
						ArrayList<String> permNew = new ArrayList<>();
						wordMap2.put(s, permNew);
						getValuesList(s).add(currentLine[i]);
					}	
				}
		//	sc.close();
			}
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		
		return this;
	
	}
	
	public ArrayList<String> getValuesList(String key) {
		return wordMap2.get(key);
	}
	
	//check if given words is valid
	public boolean isValidWord(String word) {
		String check = new Permutation(word).getNormalized();
		if(wordMap2.containsKey(check)) {
			if(wordMap2.get(check).contains(word))
				return true;
		}
		
		return false;
	}
	
	private void swap(char[] arr, int m, int n) {
		char temp = arr[m];
		arr[m] = arr[n];
		arr[n] = temp;
	}
	
	private void permutations2(String word, int left, int right, ArrayList<Permutation> res) {
		if (left == right)
				res.add(new Permutation(word));
		else {
			for (int i = left; i <= right ; i++) {
				swap(word.toCharArray(), left, i);
				permutations2(word, left + 1, right, res);
				swap(word.toCharArray(), left, i);
			}
		}
			
	}

}
