package scrabble.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import scrabble.util.Permutation;



/*
 * Desided to play around a bit, works decently with SimpleWordList,
 * couldn't make use of it for HashWordList
 *
 * The main idea was basically just to make the checking if a word is a valid word faster by calculating the hash code  
 * and only checking the list with words that have the same hash code 
 */
public class HashTableWords {
	public int size;
	public ArrayList<Permutation>[] hashTable; //or LinkedList?
	
	public HashTableWords() {
		if (SimpleWordList.words.size() == 0 ) {
			WordList wl = new SimpleWordList()
					.initFromFile("wordlists/sowpods.txt");
		}
		size = SimpleWordList.words.size();
		hashTable = new ArrayList[size*2]; //load factor 50%
		this.addAll(SimpleWordList.words);
	}
	
	public boolean add(Permutation p) {
		if(p == null) 
			return false;
		else {
			int index = p.hashCode() % size;
			if(!hashTable[index].contains(p))
			hashTable[index].add(p);
		}
		return true;
		
	}
	
	public boolean addAll(ArrayList<String> words) {
		if(words.isEmpty())
			return false;
		else {
			for(String s :words) {
				this.add(new Permutation(s));
			}
			return true;
		}
	}
	
	public boolean contains(Permutation p) {
		int index = p.hashCode() % size;
		if (hashTable[index] == null)
			return false;
		else {
			for (int i = 0; i < hashTable[index].size(); i++) {
				if(hashTable[index].get(i).equals(p))
					return true;
			}
		}
			
		
		return false;
	}
}
